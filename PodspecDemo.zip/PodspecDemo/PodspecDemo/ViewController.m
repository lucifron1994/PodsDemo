//
//  ViewController.m
//  PodspecDemo
//
//  Created by WangHong on 2017/5/21.
//  Copyright © 2017年 lucifron. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"
#import "WHLog.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [WHLog logInChinese];
    
    [WHLog logInJapanese];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
