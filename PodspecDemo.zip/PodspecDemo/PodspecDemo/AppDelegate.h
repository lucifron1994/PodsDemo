//
//  AppDelegate.h
//  PodspecDemo
//
//  Created by WangHong on 2017/5/21.
//  Copyright © 2017年 lucifron. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

